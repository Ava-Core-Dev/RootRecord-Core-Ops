Ava EcoFlow buckets (created at runtime)
devices/  — device list snapshots
quota/    — per-SN quota JSON
history/  — rolling SOC / power samples
mqtt/     — last MQTT certification payload (no secret in git)
certs/    — reserved

Keys live in RootMC .env (AVA_ECOFLOW_*). Serials: AVA_ECOFLOW_SN.
Docs: https://developer.ecoflow.com/